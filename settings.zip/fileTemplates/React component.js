import React, { Component } from 'react';
    
 class ${NAME} extends Component {
   render() {
     return(
     );
   }
 }
    
 export default ${NAME};