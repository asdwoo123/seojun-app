import React from 'react';
    
const ${NAME} = () => (
);
    
export default ${NAME};